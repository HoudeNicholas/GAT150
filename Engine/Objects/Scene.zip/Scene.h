#pragma once
#include "Object.h"
#include <list>

namespace nc
{
	class Engine;
	class GameObject;

	class Scene : public Object
	{
	public:
		virtual void create(void* data = nullptr) override;
		virtual void destroy() override;

		void read(const rapidjson::Value& value) override;

		void readGameObjects(const rapidjson::Value& value);

		void update();
		void draw();

		GameObject* Find(const std::string& name);

		void AddGameObject(GameObject* gameObject);
		void RemoveGameObject(GameObject* gameObject);
		void RemoveAllGameObjects();

	protected:
		Engine* engine{ nullptr };
		std::list<GameObject*> gameObjects;
	};
}
